import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddNewBillComponent } from './add-new-bill/add-new-bill.component';
import { ListBillsComponent } from './list-bills/list-bills.component';
import { ParentComponent } from './parent/parent.component';
import { EditBillComponent } from './edit-bill/edit-bill.component';

const routes: Routes = [
  { path: '', component: ParentComponent },
  { path: 'createbill', component: AddNewBillComponent },
  { path: 'viewbills', component: ListBillsComponent },
  { path: 'editbill/:id', component: EditBillComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
