import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Bill } from '../models/bill.model';
import { Router } from '@angular/router';
@Component({
  selector: 'app-list-bills',
  templateUrl: './list-bills.component.html',
  styleUrls: ['./list-bills.component.css']
})
export class ListBillsComponent {
  bills: Bill[] = [];
  billIds: Bill[] = [];
  constructor(private router: Router) {
    this.getAllItemsFromLocalStorage();
  }

  getAllItemsFromLocalStorage(): void {
    const items: any[] = [];
    const itemids: any[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        const value = localStorage.getItem(key);
        if (value) {
          const parsedValue = JSON.parse(value);
          itemids.push(key);
          items.push(parsedValue);
        }
      }
    }
    this.bills = items;
    this.billIds = itemids;
  }

  deleteBill(index: number) {
    const confirmation = confirm('Are you sure you want to delete this bill?')
    if (confirmation) {
      localStorage.removeItem(`${this.billIds[index]}`);
      this.getAllItemsFromLocalStorage();
    }

  }
  editBill(index: number) {
    const id = this.billIds[index];
    this.router.navigate(['editbill', id]);
  }
  clearBills() {
    const confirmation = confirm('Are you sure you want to clear all bills?');
    if (confirmation) {
      localStorage.clear();
      this.billIds = [];
      this.bills = [];
    }

  }
}
