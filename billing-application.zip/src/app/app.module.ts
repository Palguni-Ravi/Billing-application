import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddNewBillComponent } from './add-new-bill/add-new-bill.component';
import { AddNewProductComponent } from './add-new-product/add-new-product.component';
import { ListBillsComponent } from './list-bills/list-bills.component';
import { ParentComponent } from './parent/parent.component';
import { v4 as uuidv4 } from 'uuid';
import { EditBillComponent } from './edit-bill/edit-bill.component';
@NgModule({
  declarations: [
    AppComponent,
    AddNewBillComponent,
    AddNewProductComponent,
    ListBillsComponent,
    ParentComponent,
    EditBillComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
