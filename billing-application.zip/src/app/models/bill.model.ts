import { Product } from './product.model';
export interface Bill {
    products: Product[];
    total: number;
}