import { Component, EventEmitter, Output } from '@angular/core';
import { Product } from '../models/product.model';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-add-new-product',
  templateUrl: './add-new-product.component.html',
  styleUrls: ['./add-new-product.component.css']
})
export class AddNewProductComponent {
  public productName = '';
  public productPrice = 0;
  public productQuantity = 0;
  selectedProduct: string | null = null;

  data: Array<{ name: string, price: number }> = [];
  initialized = false;

  @Output() public productAddEvent = new EventEmitter();
  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.loadJsonFile();
  }

  loadJsonFile() {
    this.http.get('assets/products.json').subscribe(
      (data: any) => {
        console.log("Successfully fetched products data.");
        this.data = data;
        this.initialized = true;
      },
      (error) => {
        console.error('Error loading JSON file:', error);
      }
    );
  }
  public onProductChange(event: any) {
    const selectedProductName = event.target.value;
    const selectedProduct = this.data.find(item => item.name === selectedProductName);
    if (selectedProduct) {
      this.productName = selectedProduct.name;
      this.productPrice = selectedProduct.price;
    }
  }

  public addProduct() {
    if (this.initialized) {
      if (this.productName != '' && this.productPrice > 0 && this.productQuantity > 0) {
        const product: Product = {
          name: this.productName,
          price: this.productPrice,
          quantity: this.productQuantity
        }

        this.productAddEvent.emit(product);
      }
      this.productName = '';
      this.productPrice = 0;
      this.productQuantity = 0;
    }
    this.selectedProduct = null;
  }

}
