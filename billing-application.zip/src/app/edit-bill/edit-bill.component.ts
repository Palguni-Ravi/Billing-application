import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Bill } from '../models/bill.model';

@Component({
  selector: 'app-edit-bill',
  templateUrl: './edit-bill.component.html',
  styleUrls: ['./edit-bill.component.css']
})
export class EditBillComponent {
  bill: Bill | null = null;
  billId: string | null = null;
  constructor(private route: ActivatedRoute) {
    this.route.params.subscribe(params => {
      this.billId = params['id'];
      this.bill = JSON.parse(localStorage.getItem(this.billId as string) as string);
    });
  }
}

