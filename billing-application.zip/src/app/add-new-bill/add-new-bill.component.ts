import { Component, EventEmitter, Output, Input } from '@angular/core';
import { Product } from '../models/product.model';
import { Bill } from '../models/bill.model';
import { v4 as uuidv4 } from 'uuid';

@Component({
  selector: 'app-add-new-bill',
  templateUrl: './add-new-bill.component.html',
  styleUrls: ['./add-new-bill.component.css']
})

export class AddNewBillComponent {
  @Input() public bill: Bill | null = null;
  @Input() billId: string | null = null;
  @Input() notEdit = true;
  constructor() {
    if (this.notEdit) {
      this.billId = uuidv4();
      this.bill = {
        products: [],
        total: 0,
      };
    }
  }
  addProductToBill(product: Product) {
    if (this.bill != null) {
      this.bill.products.push(product);
      this.bill.total += product.price * product.quantity;
    }
  }
  removeProduct(index: number) {
    if (this.bill) {
      const price = this.bill.products[index].price;
      const quantity = this.bill.products[index].quantity;
      this.bill.products.splice(index, 1);
      this.bill.total -= price * quantity;
    }
  }
  updateTotal() {
    if (this.bill) {
      this.bill.total = 0;
      for (const product of this.bill.products) {
        this.bill.total += product.price * product.quantity;
      }
    }
  }
  saveBill() {
    if (!this.notEdit) {
      localStorage.removeItem(this.billId as string);
    }
    if (this.bill) {
      if (this.bill.products.length >= 1) {
        localStorage.setItem(`${this.billId}`, JSON.stringify(this.bill));
      }
    }

  }
}
