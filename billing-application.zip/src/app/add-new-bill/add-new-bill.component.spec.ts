import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNewBillComponent } from './add-new-bill.component';

describe('AddNewBillComponent', () => {
  let component: AddNewBillComponent;
  let fixture: ComponentFixture<AddNewBillComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddNewBillComponent]
    });
    fixture = TestBed.createComponent(AddNewBillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
